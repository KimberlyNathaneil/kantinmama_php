<?php

$conn = mysqli_connect('localhost','root','','data_kantin_mama');

?>